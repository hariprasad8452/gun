﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PMS_MVCAPP.Models;
using System.Text;

namespace PMS_MVCAPP.Controllers
{
    public class AdminController : Controller
    {
        [BindProperty]
        public UserModel User { get; set; }
        public async Task<IActionResult> Index()
        {
            try
            {
                List<UserModel> customersList = new List<UserModel>();
                using (var httpClient = new HttpClient())
                {

                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response
                        = await httpClient.GetAsync("http://localhost:10978/api/Admin"))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        customersList = JsonConvert.DeserializeObject<List<UserModel>>(apiResponse);
                    }
                }
                return View(customersList);
            }
            catch (Exception ex)
            {

                return RedirectToAction("Error");
            }
        }

        public IActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AdminLogin(AdminLogin aLog)
        {


            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(aLog)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = httpclient.PostAsync("http://localhost:10978/api/Admin/AdminLogin", content))
                {
                    if (response.Result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Login";
                    }
                }
            }

            return View();
        }
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                UserModel customer = null;
                using (var httpClient = new HttpClient())
                {
                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response = await httpClient.GetAsync("http://localhost:10978/api/Admin/" + id))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        customer = JsonConvert.DeserializeObject<UserModel>(apiResponse);
                    }
                }
                return View(customer);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }


        public async Task<IActionResult> Edit(int id)
        {
            UserModel customer = null;
            using (var httpclient = new HttpClient())
            {
                using (var response = await httpclient.GetAsync("http://localhost:10978/api/Admin/" + id))
                {
                    var apiresponse = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<UserModel>(apiresponse);
                }
            }
            return View(customer);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(UserModel custObj, int id)
        {


            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(custObj)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = await httpclient.PutAsync("http://localhost:10978/api/Admin/" + id, content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Customer Update";
                    }
                }
            }

            return View(custObj);
        }


        [HttpGet]
        public IActionResult Delete(int id)
        {
            if (ModelState.IsValid)
            {
                using (var httpclient = new HttpClient())
                {
                    using (var response = httpclient.DeleteAsync("http://localhost:10978/api/Admin/" + id))
                    {
                        if (response.Result.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ViewData["Message"] = "Customer Deletion failed!!";
                        }
                    }
                }
            }
            return View();
        }
    }
}
