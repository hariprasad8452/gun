﻿using Microsoft.EntityFrameworkCore;

namespace PMS_API.Models
{
    public class PMS_DbContext : DbContext
    {
        public PMS_DbContext(DbContextOptions<PMS_DbContext> options) : base(options)
        {
            
        }
      
      
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            //modelBuilder.HasSequence("BranchSequence")
            //   .StartsAt(5000).IncrementsBy(5);
            //modelBuilder.Entity<Branch>()
            //    .Property(b => b.BranchId)
            //    .HasDefaultValueSql("NEXT VALUE FOR BranchSequence");



            base.OnModelCreating(modelBuilder);
        }



        public virtual DbSet<PMS_User> Users { get; set; }

    }
}
