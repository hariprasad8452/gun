﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMS_API.Models;

namespace PMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        PMS_DbContext db = null;

        public AdminController(PMS_DbContext context)

        {

            this.db = context;

        }
        [HttpPost]

        [Route("AdminLogin")]

        public IActionResult AdminLogin([FromBody] AdminLogin aLog)

        {

            if (aLog.UserName == null || aLog.Password == null)

            {

                return BadRequest();

            }

            if (aLog.UserName == "admin@wipro.com" && aLog.Password == "admin")

            {

                return Ok("Admin Login successfull !!");

            }

            return BadRequest("Admin with provided details doesn't exist!!");

        }
        [HttpGet]

        public IActionResult GetList()

        {

            return Ok(db.Users.ToList());

        }

        [HttpGet]

        [Route("{id}")]

        public IActionResult GetById(int id)

        {

            try

            {

                var customer = db.Users.Find(id);

                return Ok(customer);

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }
        [HttpPut]

        [Route("{id}")]

        public IActionResult UpdateCustomerDetails([FromBody] UserModel customer, int id)

        {

            if (id == null)

            {

                return BadRequest();

            }

            var customerToBeUpdated = db.Users.Find(id);

            if (customerToBeUpdated.userId == id)

            {
                customerToBeUpdated.FirstName = customer.FirstName;

                customerToBeUpdated.lastName = customer.lastName;
            
                customerToBeUpdated.DOB = customer.DOB;
                customerToBeUpdated.Address = customer.Address;
                customerToBeUpdated.City = customer.City;
                customerToBeUpdated.State = customer.State;
                customerToBeUpdated.Country = customer.Country;
                customerToBeUpdated.Pincode = customer.Pincode;
                customerToBeUpdated.PhoneNumber = customer.PhoneNumber;
                customerToBeUpdated.Email = customer.Email;
                customerToBeUpdated.Gender = customer.Gender;


                db.Users.Update(customerToBeUpdated);

                db.SaveChanges();

                return Ok("Customer details Updated successfully !!");

            }

            return BadRequest("Invalid Customer Details...");

        }
        [HttpDelete]

        [Route("{id}")]

        public IActionResult DeleteUser(int id)

        {

            if (id == null)

            {

                return BadRequest();

            }

            var userToBeDeleted = db.Users.Find(id);

            if (userToBeDeleted != null)

            {

                db.Users.Remove(userToBeDeleted);

                db.SaveChanges();

                return Ok("User Deleted successfully !!");

            }

            return BadRequest("User with provided details doesn't exist!!");

        }

    }
}

